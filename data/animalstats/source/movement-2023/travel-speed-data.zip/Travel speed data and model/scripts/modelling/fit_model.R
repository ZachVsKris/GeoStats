# Project: Movement-model
# Objectives: Load species-level travel speed data, fit and compare Stan models, output parameters and figures
rm(list=ls())
gc(full = TRUE)

options("digits" = 15)

set.seed(123)

#
# Packages -----------------------------------------------------------
#

library(tidyverse) # need this for modifying dataframes and for the 'piping' operator %>%
library(scales) # useful package
library(writexl) # package to export to excel file

# Bayesian packages
library(rstan)
library(coda)
library(BayesianTools)

#
# 1) Load data ---------------------------------------------------------------
#

# species-level observations (i.e. geometric means calculated if multiple individuals are measured within the same study)
df_spp <- read.csv("data/processed/df_spp.csv", 
                   header = TRUE, sep = ",")

#
# 2) Modify dataframe of observations to work with Stan model -------------------------------------
#

# Add columns for log10(speed) and log10(body mass) 
df_spp <- df_spp %>%
  mutate(move_log10bodymass_kg = log10(move_bodymass_kg),
         move_log10avgspeed_ms = log10(move_avgspeed_ms))

# Added numeric columns for input to stan list
# First make sure all characters are coded as factors
df_obs <- df_spp %>% 
  mutate_if(is.character, factor) %>%
  mutate(y = move_log10avgspeed_ms,
         x = move_log10bodymass_kg, # log10 body mass kg (M in the  model's numerator, written in log-linear form because it's easier to read)
         x_raw = move_bodymass_kg, # body mass kg (M in the model's denominator, the ugly stuff within the log10 bracket which we can't write in log-linear form)
         Mode = as.numeric(move_movement_mode), # 1=flying 2=running 3=swimming 
         Medium = as.numeric(move_medium), # 1=air 2=water
         Ref = as.numeric(move_speed_ref)
  )

#
# 3) Fit Stan models: General setup for all models ----------------------------------
#

# Format observed data as list for Stan
stan_dat <- list("N" = nrow(df_obs),
                 "N_Ref" = length(unique(df_obs$Ref)),
                 "Ref" = df_obs$Ref,
                 "N_Mode" = length(unique(df_obs$Mode)),
                 "Mode" = df_obs$Mode,
                 "N_Medium" = length(unique(df_obs$Medium)),
                 "Medium" = df_obs$Medium,
                 "y" = df_obs$y,
                 "x" = df_obs$x,
                 "x_raw" = df_obs$x_raw
)

# Settings
rstan_options(auto_write = TRUE)
options(mc.cores = 3) # number of CPU cores

# Setup MCMC sampler
chains = 3
warmup = 1500
iter   = 3000

################
################
################

#
# 3.1a) Metabolic (shared slope): Stan code ----------------------------------------
# We let v_zero vary across movement_mode but assume a common scaling exponent c across movement_mode
# move_movement_mode: 1 = flying, 2 = running, 3 swimming
#
# Name: powr_a
# Response: y = move_log10avgspeed_ms (continuous)
# Predictors: x = move_log10bodymass_kg (continuous) ;
# No pooling: v_zero (move_movement_mode); 
# Complete pooling: c;
# Partial pooling: None
# Model: y = v_zero_Mode[Mode] + c*x[i]
#

code_all_powr_a <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // mean of parameter h across movement modes (no pooling)
  real<lower=0> c; // mean of parameter c (complete pooling)

} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // power law function predicts log10speed using log10bodymass
  // alternatively: use bodymass and log10(x[i])^c_Mode)
  y_hat[i] = log10(v_zero_Mode[Mode[i]]) + c*x[i];
  }
}
model {
  // priors
  sigma ~ cauchy(0, 10); // residuals for observation error
  
  for (j in 1:N_Mode) { 
  v_zero_Mode[j] ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling);
  }
  
  c ~ normal(0, 1);// Prior for parameter c (complete pooling)

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.1a) Metabolic (shared slope): Stan model fitting (all data, powr_a) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   c = 1,
                   sigma = 1
)),chains)

model_all_powr_a = stan_model(model_code=code_all_powr_a)
# optional: 
# saveRDS(model_all_powr_a, file="output/model_all_powr_a.rds")

# Recover parameters with stan
fit_all_powr_a  = sampling(model_all_powr_a,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           init=init,
                           warmup=warmup,
                           control=list(adapt_delta=0.999)
)
# optional:
# saveRDS(fit_all_powr_a, "output/fit_all_powr_a.rds")

# Model summary 
print(fit_all_powr_a, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_powr_a <- as.matrix(fit_all_powr_a)

################
################
################

#
# 3.1b) Metabolic (variable slope): Stan code ----------------------------------------
# We let v_zero and the allometric exponent c both vary across movement_mode.
# The latter implies that active metabolic rate scales differently across different movement modes (a weak assumption),
# and the minimum cost of locomotion scales similarly across movement modes (a strong assumption).
#
# Name: powr_b
# Response: y = move_log10avgspeed_ms (continuous)
# Predictors: x = move_log10bodymass_kg (continuous) ;
# No pooling: v_zero (move_movement_mode); c (move_movement_mode);
# Complete pooling: None
# Partial pooling: None
# Model: y = v_zero_Mode[Mode] + c_Mode[Mode]*x[i]
#

code_all_powr_b <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // mean of v_zero parameter across movement modes (no pooling)
  vector<lower=0>[N_Mode] c_Mode; // mean of c parameter across movement modes (no pooling)

} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // power law function predicts log10speed using log10bodymass (no pooling: v_zero_Mode, c_Mode)
  // alternatively: use bodymass and log10(x[i])^c_Mode)
  y_hat[i] = log10(v_zero_Mode[Mode[i]]) + c_Mode[Mode[i]]*x[i];
  }
}
model {
  // priors
  sigma ~ cauchy(0, 10); // residuals for observation error
  
  for (j in 1:N_Mode) { 
  v_zero_Mode[j] ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling);
  c_Mode[j] ~ normal(0, 1); // Prior for each Movement mode (no pooling);
  }

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.1b) Metabolic (variable slope): Stan model fitting (all data, powr_b) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode   = rep(1,3),
                   c_Mode   = rep(1,3),
                   sigma   = 1
)),chains)

model_all_powr_b = stan_model(model_code=code_all_powr_b)
# optional: 
# saveRDS(model_all_powr_b, file="output/model_all_powr_b.rds") 

# Recover parameters with stan
fit_all_powr_b  = sampling(model_all_powr_b,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           init=init,
                           warmup=warmup,
                           control=list(adapt_delta=0.999)
)
# optional:
# saveRDS(fit_all_powr_b, "output/fit_all_powr_b.rds")

# Model summary 
print(fit_all_powr_b, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_powr_b <- as.matrix(fit_all_powr_b)

################
################
#############

#
# 3.2a) Constant heat-dissipation (shared slope): stan code -------------------------------------
# We add the assumption that conductance scales independently of body mass (via k_lamda only.
# This implies that the allometric scaling expoenent d = 0
#
# Name: satr_a
# Response: y = move_log10avgspeed_ms (continous)
# Predictors: x = move_log10bodymass_kg (continous); x_raw = move_bodymass_kg (continous);
# Predictors: Mode = move_movement_mode (3 levels); 
# No pooling: v_zero (move_movement_mode); 
# Complete pooling: c, k_zero, [assume: d = 0]
# Partial pooling: None
# Model: y = -log10(k_zero) + c*x[i] - log10(pow(x_raw[i],c) + (1/k_zero*v_zero[Mode]));
#

code_all_satr_a <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  vector[N] x_raw; // predictor: bodymass 
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // means of v_zero parameter across movement modes (no pooling)
  real<lower=0> c; // mean of c parameter (complete pooling)
  real<lower=0> k_zero; // mean of k_zero parameter (complete pooling)
} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // Michaelis-menten function predicts log10speed using bodymass (no pooling: v_zero; complete pooling: c, k_zero)
  // The numerator of the model is written in log-linear form (that's why input x is log10 body mass)
  // The denominator of the model can't be fully written in log-linear form (that's why input x_raw is body mass, not log10 body mass)
    y_hat[i] = -log10(k_zero) + c*x[i] - log10(pow(x_raw[i],c) + ((1/(k_zero*v_zero_Mode[Mode[i]]))));
  }
}
model {
  // priors
  sigma ~ cauchy(0, 2); // residuals for observation error
  
  c ~ normal(1, 2); // (complete pooling)
  k_zero ~ gamma(2, 0.01); // (complete pooling); gamma(n,(n-1)/m)
  
  v_zero_Mode ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling); gamma(n,(n-1)/m) 0.01, 2

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.2a) Constant heat-dissipation (shared slope): Stan model fitting (all data, satr_a) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   c = 1,
                   k_zero = 1,
                   sigma = 1
)),chains)

model_all_satr_a = stan_model(model_code=code_all_satr_a)
# optional: 
# saveRDS(model_all_satr_a, file="ouput/model_all_satr_a.rds") 

# Recover parameters with stan
fit_all_satr_a  = sampling(model_all_satr_a,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           warmup=warmup,
                           init = init,
                           control=list(adapt_delta=0.999, max_treedepth = 15)
)
# optional:
# saveRDS(fit_all_satr_a, "output/fit_all_satr_a.rds")

# Model summary 
print(fit_all_satr_a, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_satr_a <- as.matrix(fit_all_satr_a)

################
################
#############

#
# 3.2b) Constant heat-dissipation (variable slope): stan code -------------------------------------
# We add the assumption that conductance scales independently of body mass (via k_lamda only)
# This implies that the allometric scaling expoenent d = 0
# We also add the assumption the allometric exponent c varies with movement_mode.
# This implies that active metabolic rate scales differently across different movement modes (a weak assumption)
#
# Name: satr_b
# Response: y = move_log10avgspeed_ms (continous)
# Predictors: x = move_log10bodymass_kg (continous); x_raw = move_bodymass_kg (continous);
# Predictors: Mode = move_movement_mode (3 levels); 
# No pooling: v_zero (move_movement_mode); c (move_movement_mode)
# Complete pooling:  k_zero, [assume: d = 0]
# Partial pooling: None
# Model: y = -log10(k_zero) + c[Mode]*x[i] - log10(pow(x_raw[i],c[Mode]) + (1/(k_zero*v_zero[Mode])));
#

code_all_satr_b <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  vector[N] x_raw; // predictor: bodymass 
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // means of v_zero parameter across movement modes (no pooling)
  vector<lower=0>[N_Mode] c_Mode; // means of a parameter across movement modes (no pooling)
  real<lower=0> k_zero; // mean of k_zero parameter (complete pooling)
} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // Michaelis-menten function predicts log10speed using bodymass (no pooling: c, v_zero; complete pooling: k_zero)
  // The numerator of the model is written in log-linear form (that's why input x is log10 body mass)
  // The denominator of the model can't be fully written in log-linear form (that's why input x_raw is body mass, not log10 body mass)
    y_hat[i] = -log10(k_zero) + c_Mode[Mode[i]]*x[i] - log10(pow(x_raw[i],c_Mode[Mode[i]]) + ((1/(k_zero*v_zero_Mode[Mode[i]]))));
  }
}
model {
  // priors
  sigma ~ cauchy(0, 2); // residuals for observation error
  
  k_zero ~ gamma(2, 0.01); // (complete pooling); gamma(n,(n-1)/m)
  
  c_Mode ~ normal(1, 2); // Prior for each Movement mode (no pooling)
  v_zero_Mode ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling); gamma(n,(n-1)/m)

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.2b) Constant heat-dissipation (variable slope): Stan model fitting (all data, satr_b) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   c_Mode = rep(1,3),
                   k_zero = 1,
                   sigma = 1
)),chains)

model_all_satr_b = stan_model(model_code=code_all_satr_b)
# optional: 
# saveRDS(model_all_satr_b, file="output/model_all_satr_b.rds") 

# Recover parameters with stan
fit_all_satr_b  = sampling(model_all_satr_b,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           warmup=warmup,
                           init = init,
                           control=list(adapt_delta=0.999, max_treedepth = 15)
)
# Optional:
# saveRDS(fit_all_satr_b, "output/fit_all_satr_b.rds")

# Model summary 
print(fit_all_satr_b, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_satr_b <- as.matrix(fit_all_satr_b)

################
################
#############

#
# 3.3c) Constant heat-dissipation (shared slope and variable maxima): Stan model fitting (all data, satr_c) --------
# We retain the lumped parameter v_zero and let it vary between flying, running, swimming (i.e. via movement_mode)
# We also let k_zero vary among water vs air (via move_medium).
# This accounts for the higher thermal conductance experienced by aquatic animals as k_zero is derived from conductance.
# move_movement_mode: 1 = flying, 2 = running, 3 = swimming
# move_medium: 1 = air, 2 = water
#
# Name: satr_c
# Response: y = move_log10avgspeed_ms (continous)
# Predictors: x = move_log10bodymass_kg (continous); x_raw = move_bodymass_kg (continous);
# Predictors: Mode = move_movement_mode (3 levels); Medium = move_medium (2 levels)
# No pooling: v_zero (move_movement_mode); k_zero (move_medium)
# Complete pooling: c
# Partial pooling: None
# Model: y = -log10(k[Medium]) + c*x[i] - log10(pow(x_raw[i],c) + (1/(k_zero[Medium]*v_zero[Mode])));
#

code_all_satr_c <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  int<lower=1> N_Medium; // number of movement mediums lol (2 level factor)
  int<lower=1, upper=N_Medium> Medium[N]; // map observations to movement medium
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  vector[N] x_raw; // predictor: bodymass 
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // means of v_zero parameter across movement modes (no pooling)
  vector<lower=0>[N_Medium] k_zero_Medium; // means of k_zero parameter across movement mediums (no pooling)
  real<lower=0> c; // mean of c parameter (complete pooling)

} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // Michaelis-menten function predicts log10speed using bodymass (no pooling: v_zero, k_zero; complete pooling: c, d)
  // The numerator of the model is written in log-linear form (that's why input x is log10 body mass)
  // The denominator of the model can't be fully written in log-linear form (that's why input x_raw is body mass, not log10 body mass)
    y_hat[i] = -log10(k_zero_Medium[Medium[i]]) + c*x[i] - log10(pow(x_raw[i],c) + ((1/(k_zero_Medium[Medium[i]]*v_zero_Mode[Mode[i]]))));
  }
}
model {
  // priors
  sigma ~ cauchy(0, 2); // residuals for observation error
  
  c ~ normal(1, 2); // (complete pooling)
 
  k_zero_Medium ~ gamma(2, 0.01); // Prior for each Movement medium (no pooling); gamma(n,(n-1)/m)
  v_zero_Mode ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling); gamma(n,(n-1)/m)

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.3c) Constant heat-dissipation (shared slope and variable maxima): Stan model fitting (all data, satr_c) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   k_zero_Medium = rep(1,2),
                   c = 1,
                   sigma = 1
)),chains)

model_all_satr_c = stan_model(model_code=code_all_satr_c)
# optional: 
# saveRDS(model_all_satr_c, file="output/model_all_satr_c.rds") 

# Recover parameters with stan
fit_all_satr_c  = sampling(model_all_satr_c,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           warmup=warmup,
                           init = init,
                           control=list(adapt_delta=0.999, max_treedepth = 15)
)
# Optional:
# saveRDS(fit_all_satr_c, "output/fit_all_satr_c.rds")

# Model summary 
print(fit_all_satr_c, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_satr_c <- as.matrix(fit_all_satr_c)

################
################
#############

#
# 3.3a) Allometric heat-dissipation (shared slope): stan code (all data, hump_a) -------------------------------------
# We add the assumption that conductance scales with body mass (via k_lamda and allometric exponent d)
#
# Name: hump_a
# Response: y = move_log10avgspeed_ms (continous)
# Predictors: x = move_log10bodymass_kg (continous); x_raw = move_bodymass_kg (continous);
# Predictors: Mode = move_movement_mode (3 levels); 
# No pooling: v_zero (move_movement_mode); 
# Complete pooling: c, d, k_lambda
# Partial pooling: None
# Model: y = -log10(k) + c*x[i] - log10(pow(x_raw[i],c+d) + (1/(k_lambda*v_zero[Mode])));
#

code_all_hump_a <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  vector[N] x_raw; // predictor: bodymass 
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // means of v_zero parameter across movement modes (no pooling)
  real<lower=0> c; // mean of c parameter (complete pooling)
  real<lower=0> d; // mean of d parameter (complete pooling)
  real<lower=0> k_lambda; // mean of k_lambda parameter (complete pooling)
} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // Michaelis-menten function predicts log10speed using bodymass (no pooling: v_zero; complete pooling: c, d, k_lambda)
  // The numerator of the model is written in log-linear form (that's why input x is log10 body mass)
  // The denominator of the model can't be fully written in log-linear form (that's why input x_raw is body mass, not log10 body mass)
    y_hat[i] = -log10(k_lambda) + c*x[i] - log10(pow(x_raw[i],c + d) + ((1/(k_lambda*v_zero_Mode[Mode[i]]))));
  }
}
model {
  // priors
  sigma ~ cauchy(0, 2); // residuals for observation error
  
  c ~ normal(1, 2); // (complete pooling)
  d ~ normal(1, 2); // (complete pooling)
  k_lambda ~ gamma(2, 0.01); // (complete pooling); gamma(n,(n-1)/m)
  
  v_zero_Mode ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling); gamma(n,(n-1)/m)

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.3a) Allometric heat-dissipation (shared slope): Stan model fitting (all data, hump_a) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   c = 1,
                   d = 1,
                   k_lambda = 1,
                   sigma = 1
)),chains)

model_all_hump_a = stan_model(model_code=code_all_hump_a)
# optional: 
# saveRDS(model_all_hump_a, file="output/model_all_hump_a.rds") 

# Recover parameters with stan
fit_all_hump_a  = sampling(model_all_hump_a,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           warmup=warmup,
                           init = init,
                           control=list(adapt_delta=0.999, max_treedepth = 15)
)
# Optional:
# saveRDS(fit_all_hump_a, "output/fit_all_hump_a.rds")

# Model summary 
print(fit_all_hump_a, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_hump_a <- as.matrix(fit_all_hump_a)

################
################
#############

#
# 3.3b) Allometric heat-dissipation (variable slope):  Stan model fitting (all data, hump_b) --------
# We add the assumption that conductance scales with body mass (via k_lamda and allometric exponent d)
# We also add the assumption the allometric exponent c varies with movement_mode.
# This implies that active metabolic rate scales differently across different movement modes (a weak assumption)
#
# Name: hump_b
# Response: y = move_log10avgspeed_ms (continous)
# Predictors: x = move_log10bodymass_kg (continous); x_raw = move_bodymass_kg (continous);
# Predictors: Mode = move_movement_mode (3 levels); 
# No pooling: v_zero (move_movement_mode); c (move_movement_mode)
# Complete pooling: d, k_lambda
# Partial pooling: None
# Model: y = log10(k_lambda) + c[Mode]*x[i] - log10(pow(x_raw[i],c[Mode]+d) + (1/(k_lambda*v_zero[Mode])));
#

code_all_hump_b <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  vector[N] x_raw; // predictor: bodymass 
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // means of v_zero parameter across movement modes (no pooling)
  vector<lower=0>[N_Mode] c_Mode; // means of a parameter across movement modes (no pooling)
  real<lower=0> d; // mean of d parameter (complete pooling)
  real<lower=0> k_lambda; // mean of k_lambda parameter (complete pooling)
} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // Michaelis-menten function predicts log10speed using bodymass (no pooling: c, v_zero; complete pooling: d, k_lambda)
  // The numerator of the model is written in log-linear form (that's why input x is log10 body mass)
  // The denominator of the model can't be fully written in log-linear form (that's why input x_raw is body mass, not log10 body mass)
    y_hat[i] = -log10(k_lambda) + c_Mode[Mode[i]]*x[i] - log10(pow(x_raw[i],c_Mode[Mode[i]] + d) + ((1/(k_lambda*v_zero_Mode[Mode[i]]))));
  }
}
model {
  // priors
  sigma ~ cauchy(0, 2); // residuals for observation error
  
  d ~ normal(1, 2); // (complete pooling)
  k_lambda ~ gamma(2, 0.01); // (complete pooling); gamma(n,(n-1)/m)
  
  c_Mode ~ normal(1, 2); // Prior for each Movement mode (no pooling)
  v_zero_Mode ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling); gamma(n,(n-1)/m)

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.3b) Allometric heat-dissipation (variable slope): Stan model fitting (all data, hump_b) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   c_Mode = rep(1,3),
                   d = 1,
                   k_lambda = 1,
                   sigma = 1
)),chains)

model_all_hump_b = stan_model(model_code=code_all_hump_b)
# optional: 
# save(model_all_hump_b, file="output/model_hump_b.rds") 

# Recover parameters with stan
fit_all_hump_b  = sampling(model_all_hump_b,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           warmup=warmup,
                           init = init,
                           control=list(adapt_delta=0.999, max_treedepth = 15)
)
# Optional:
# saveRDS(fit_all_hump_b, "output/fit_all_hump_b.rds")

# Model summary 
print(fit_all_hump_b, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_hump_b <- as.matrix(fit_all_hump_b)

################
################
#############

#
# 3.3c) Allometric heat-dissipation (shared slope and variable maxima): Stan model fitting (all data, hump_c) --------
# We retain the lumped parameter v_zero and let it vary between flying, running, swimming (i.e. via movement_mode)
# We also let k_lambda vary among water vs air (via move_medium).
# This accounts for the higher thermal conductance experienced by aquatic animals as k_lambda is derived from conductance.
# move_movement_mode: 1 = flying, 2 = running, 3 = swimming
# move_medium: 1 = air, 2 = water
#
# Name: hump_c
# Response: y = move_log10avgspeed_ms (continous)
# Predictors: x = move_log10bodymass_kg (continous); x_raw = move_bodymass_kg (continous);
# Predictors: Mode = move_movement_mode (3 levels); Medium = move_medium (2 levels)
# No pooling: v_zero (move_movement_mode); k_lambda (move_medium)
# Complete pooling: c, d
# Partial pooling: None
# Model: y = -log10(k[Medium]) + c*x[i] - log10(pow(x_raw[i],c+d) + (1/(k_lambda[Medium]*v_zero[Mode])));
#

code_all_hump_c <- "
data {
// inputs
  int<lower=1> N; // number of observations
  int<lower=1> N_Mode; // number of movement modes (3 level factor)
  int<lower=1, upper=N_Mode> Mode[N]; // map observations to movement mode
  int<lower=1> N_Medium; // number of movement mediums lol (2 level factor)
  int<lower=1, upper=N_Medium> Medium[N]; // map observations to movement medium
  vector[N] y; // response variable: log10speed
  vector[N] x; // predictor: log10bodymass
  vector[N] x_raw; // predictor: bodymass 
  }
parameters {
  real<lower=0> sigma; // residual standard deviation
  vector<lower=0>[N_Mode] v_zero_Mode; // means of v_zero parameter across movement modes (no pooling)
  vector<lower=0>[N_Medium] k_lambda_Medium; // means of k_lambda parameter across movement mediums (no pooling)
  real<lower=0> c; // mean of c parameter (complete pooling)
  real<lower=0> d; // mean of d parameter (complete pooling)

} 
transformed parameters {
  vector[N] y_hat; // predicted y for each observation of and x
  
  for (i in 1:N) {
  // Michaelis-menten function predicts log10speed using bodymass (no pooling: v_zero, k_lambda; complete pooling: c, d)
  // The numerator of the model is written in log-linear form (that's why input x is log10 body mass)
  // The denominator of the model can't be fully written in log-linear form (that's why input x_raw is body mass, not log10 body mass)
    y_hat[i] = -log10(k_lambda_Medium[Medium[i]]) + c*x[i] - log10(pow(x_raw[i],c + d) + ((1/(k_lambda_Medium[Medium[i]]*v_zero_Mode[Mode[i]]))));
  }
}
model {
  // priors
  sigma ~ cauchy(0, 2); // residuals for observation error
  
  c ~ normal(1, 2); // (complete pooling)
  d ~ normal(1, 2); // (complete pooling)
 
  k_lambda_Medium ~ gamma(2, 0.01); // Prior for each Movement medium (no pooling); gamma(n,(n-1)/m)
  v_zero_Mode ~ gamma(2, 0.01); // Prior for each Movement mode (no pooling); gamma(n,(n-1)/m)

  // likelihood 
  y ~ normal(y_hat, sigma); // 
}
generated quantities {
  // pointwise log-likelihoods for WAIC estimation
  vector[N] log_lik;
  for (i in 1:N) {
  log_lik[i] = normal_lpdf(y[i] | y_hat[i], sigma);
  }
}
"

#
# 3.3c) Allometric heat-dissipation (shared slope and variable maxima): Stan model fitting (all data, hump_c) --------
#

# Initial values for parameters
init=rep(list(list(v_zero_Mode = rep(1,3),
                   k_lambda_Medium = rep(1,2),
                   c = 1,
                   d = 1,
                   sigma = 1
)),chains)

model_all_hump_c = stan_model(model_code=code_all_hump_c)
# optional: 
# saveRDS(model_all_hump_c, file="output/model_all_hump_c.rds") 

# Recover parameters with stan
fit_all_hump_c  = sampling(model_all_hump_c,
                           data=stan_dat,
                           chains=chains,
                           iter=iter,
                           warmup=warmup,
                           init = init,
                           control=list(adapt_delta=0.999, max_treedepth = 15)
)
# Optional:
# saveRDS(fit_all_hump_c, "output/fit_all_hump_c.rds")

# Model summary 
print(fit_all_hump_c, digits = 3, probs = c(0.025, 0.975))

# Extract posterior
posterior_all_hump_c <- as.matrix(fit_all_hump_c)

################
################
#############

#
# 4) Model comparison via Leave-one-out cross validation (LOOIC) --------------------------------------------------------
#

# Optional:
# Load model fits from Rdata
# fit_all_powr_a <- readRDS("output/fit_all_powr_a.rds")
# fit_all_powr_b <- readRDS("output/fit_all_powr_b.rds")
# fit_all_satr_a <- readRDS("output/fit_all_satr_a.rds")
# fit_all_satr_b <- readRDS("output/fit_all_satr_b.rds")
# fit_all_satr_c <- readRDS("output/fit_all_satr_c.rds")
# fit_all_hump_a <- readRDS("output/fit_all_hump_a.rds")
# fit_all_hump_b <- readRDS("output/fit_all_hump_b.rds")
# fit_all_hump_c <- readRDS("output/fit_all_hump_c.rds")

# 4.1) Run LOOIC for each model -------------------------------------------

# Run LOOIC for each model
loo_all_powr_a <- loo(fit_all_powr_a, cores = 3) # Power law common slope and variable v_zero via Mode
loo_all_powr_b <- loo(fit_all_powr_b, cores = 3) # Power law variable slope and v_zero via Mode
loo_all_satr_a <- loo(fit_all_satr_a, cores = 3) # Saturating common slope and variable v_zero via Mode
loo_all_satr_b <- loo(fit_all_satr_b, cores = 3) # Saturating variable slope and v_zero via Mode
loo_all_satr_c <- loo(fit_all_satr_c, cores = 3) # Saturating common slope and variable v_zero via Mode plus variable k_lambda via Medium (air vs water)
loo_all_hump_a <- loo(fit_all_hump_a, cores = 3) # Hump-shaped common slope and variable v_zero via Mode
loo_all_hump_b <- loo(fit_all_hump_b, cores = 3) # Hump-shaped variable slope and v_zero via Mode
loo_all_hump_c <- loo(fit_all_hump_c, cores = 3) # Hump-shaped common slope and variable v_zero via Mode plus variable k_lambda via Medium (air vs water)

# Run pairwise model comparison for three main models (H1a, H2a, H3a)
model_compare_main <- loo::loo_compare(list(
  "Power law (shared slope)" = loo_all_powr_a, 
  "Saturating (shared slope)" = loo_all_satr_a,
  "Hump-shaped (shared slope)" = loo_all_hump_a)
) %>% as.data.frame()

# Run pairwise model comparison for all eight models (H1a, H1b, H2a, H2b, H2c, H3a, H3b, H3c)
model_compare_extra <- loo::loo_compare(list(
  "Power law (shared slope)" = loo_all_powr_a,
  "Power law (variable slope)" = loo_all_powr_b,
  "Saturating (shared slope)" = loo_all_satr_a,
  "Saturating (variable slope)" = loo_all_satr_b,
  "Saturating (shared slope and variable maxima)" = loo_all_satr_c,
  "Hump-shaped (shared slope)" = loo_all_hump_a,
  "Hump-shaped (variable slope)" = loo_all_hump_b,
  "Hump-shaped (shared slope and variable maxima)" = loo_all_hump_c)
) %>% as.data.frame()

# 4.2) Create LOOIC summary tables ---------------------------------------------

# Put LOOIC output into a nice table for three main models
table_looic_main <- data.frame(Model = rownames(model_compare_main),
                               LOOIC = model_compare_main$looic,
                               delta_LOOIC = model_compare_main$looic - min(model_compare_main$looic),
                               SE_delta_LOOIC = 2*model_compare_main$se_diff,
                               delta_ELPD = model_compare_main$elpd_diff,
                               SE_delta_elpd = model_compare_main$se_diff,
                               Performance = ifelse(model_compare_main$looic - min(model_compare_main$looic) <= 4*model_compare_main$se_diff, "Best fit", "Worse fit")
)

# Put LOOIC output into a nice table for all models plus the extra models recommended by reviewers
table_looic_extra <- data.frame(Model = rownames(model_compare_extra),
                                LOOIC = model_compare_extra$looic,
                                delta_LOOIC = model_compare_extra$looic - min(model_compare_extra$looic),
                                SE_delta_LOOIC = 2*model_compare_extra$se_diff,
                                delta_ELPD = model_compare_extra$elpd_diff,
                                SE_delta_elpd = model_compare_extra$se_diff,
                                Performance = ifelse(model_compare_extra$looic - min(model_compare_extra$looic) <= 4*model_compare_extra$se_diff, "Best fit", "Worse fit")
)

# Write LOOIC tables to file
write.csv(table_looic_main, "output/model_comparison_looic_main.csv")
write.csv(table_looic_extra, "output/model_comparison_looic_extra.csv")

################
################
#############

# 6) Parameters estimates ---------------------------------------

# 6.1a) Print parameter estimates joint best-fitting model ---------------------------------------

# Select joint best-fitting model
posterior_1 <- posterior_all_hump_a
fit_1 <- fit_all_hump_a

# Names of the constants and exponents need to be renamed to match paper
# Paper: c, d, v_zero[flying,running,swimming], Lambda_zero
# Code:  a, b, h_Mode[1,2,3], k

# Posterior estimates dataframe
posterior_1_df <- data.frame(sigma = posterior_1[, "sigma"],
                             v_zero_flying = posterior_1[, "v_zero_Mode[1]"],
                             v_zero_running = posterior_1[, "v_zero_Mode[2]"],
                             v_zero_swimming = posterior_1[, "v_zero_Mode[3]"],
                             c = posterior_1[, "c"],
                             d = posterior_1[, "d"],
                             k_lambda = posterior_1[, "k_lambda"]
)

# Posterior estimates summarised
fit_summary_1 <- summary(fit_1, pars = c("sigma",
                                         "v_zero_Mode[1]", "v_zero_Mode[2]", "v_zero_Mode[3]", 
                                         "c",
                                         "d",
                                         "k_lambda"), 
                         digits = 3, probs = c(0.05, 0.95))$summary

# Summary table of parameter estimates via cbind
parameters_summary_1 <- posterior_1_df %>%
  summarise_all(median) %>% 
  gather("parameter", "median") %>%
  cbind(fit_summary_1)

# Write to file
write.csv(parameters_summary_1, "output/parameters_1.csv")

# 6.1b) Print parameter estimates joint best-fitting model ---------------------------------------

# Select joint best-fitting model
posterior_2 <- posterior_all_satr_c
fit_2 <- fit_all_satr_c

# Names of the constants and exponents need to be renamed to match paper
# Paper: c, d, v_zero[flying,running,swimming], Lambda_zero
# Code:  a_Mode[1,2,3], b, h_Mode[1,2,3], k

# posterior_2 estimates dataframe
posterior_2_df <- data.frame(sigma = posterior_2[, "sigma"],
                             v_zero_flying = posterior_2[, "v_zero_Mode[1]"],
                             v_zero_running = posterior_2[, "v_zero_Mode[2]"],
                             v_zero_swimming = posterior_2[, "v_zero_Mode[3]"],
                             c = posterior_2[, "c"],
                             k_lambda_air = posterior_2[, "k_zero_Medium[1]"],
                             k_lambda_water = posterior_2[, "k_zero_Medium[2]"]
)

# Posterior estimates summarised
fit_summary_2 <- summary(fit_2, pars = c("sigma",
                                         "v_zero_Mode[1]", "v_zero_Mode[2]", "v_zero_Mode[3]", 
                                         "c",
                                         "k_zero_Medium[1]", "k_zero_Medium[2]"), 
                         digits = 3, probs = c(0.05, 0.95))$summary

# Summary table of parameter estimates via cbind
parameters_summary_2 <- posterior_2_df %>%
  summarise_all(median) %>% 
  gather("parameter", "median") %>%
  cbind(fit_summary_2)

# Write to file
write.csv(parameters_summary_2, "output/parameters_2.csv")

# 6.1c) Print parameter estimates joint best-fitting model ---------------------------------------

# Select joint best-fitting model
posterior_3 <- posterior_all_hump_c
fit_3 <- fit_all_hump_c

# Names of the constants and exponents need to be renamed to match paper
# Paper: c, d, v_zero[flying,running,swimming], Lambda_zero
# Code:  a_Mode[1,2,3], b, h_Mode[1,2,3], k

# posterior_3 estimates dataframe
posterior_3_df <- data.frame(sigma = posterior_3[, "sigma"],
                             v_zero_flying = posterior_3[, "v_zero_Mode[1]"],
                             v_zero_running = posterior_3[, "v_zero_Mode[2]"],
                             v_zero_swimming = posterior_3[, "v_zero_Mode[3]"],
                             c = posterior_3[, "c"],
                             d = posterior_3[, "d"],
                             k_lambda_air = posterior_3[, "k_lambda_Medium[1]"],
                             k_lambda_water = posterior_3[, "k_lambda_Medium[2]"]
)

# Posterior estimates summarised
fit_summary_3 <- summary(fit_3, pars = c("sigma",
                                         "v_zero_Mode[1]", "v_zero_Mode[2]", "v_zero_Mode[3]", 
                                         "c", "d",
                                         "k_lambda_Medium[1]", "k_lambda_Medium[2]"), 
                         digits = 3, probs = c(0.05, 0.95))$summary

# Summary table of parameter estimates via cbind
parameters_summary_3 <- posterior_3_df %>%
  summarise_all(median) %>% 
  gather("parameter", "median") %>%
  cbind(fit_summary_3)

# Write to file
write.csv(parameters_summary_3, "output/parameters_3.csv")

################
################
#############

# 6) Plot main model predictions for paper -----------------------------------------------------

# Optional:
# Load model posteriors from Rdata
# posterior_all_powr_a <- readRDS("output/fit_all_powr_a.rds") %>% as.matrix
# posterior_all_powr_b <- readRDS("output/fit_all_powr_b.rds") %>% as.matrix
# posterior_all_satr_a <- readRDS("output/fit_all_satr_a.rds") %>% as.matrix
# posterior_all_satr_b <- readRDS("output/fit_all_satr_b.rds") %>% as.matrix
# posterior_all_satr_c <- readRDS("output/fit_all_satr_c.rds") %>% as.matrix
# posterior_all_hump_a <- readRDS("output/fit_all_hump_a.rds") %>% as.matrix
# posterior_all_hump_b <- readRDS("output/fit_all_hump_b.rds") %>% as.matrix
# posterior_all_hump_c <- readRDS("output/fit_all_hump_c.rds") %>% as.matrix

# Set shared point style for figure and legend (based on taxon_group)
fig_points <- c(0,16,4,1,6,17,8,15)[as.numeric(df_obs$taxon_group)]
legend_names <- c(levels(df_obs$taxon_group))
legend_points <- c(0,16,4,1,6,17,8,15)

# Set shared limits for axes
xlim_main = c(min(df_obs$move_log10bodymass_kg)-1.5,max(df_obs$move_log10bodymass_kg)+2)
ylim_main = c(min(df_obs$move_log10avgspeed_ms)-0.5,max(df_obs$move_log10avgspeed_ms)+0.5)

# Set shared settings for plot (PLOS Biology guidelines for .tiff, full page width, 2/3 aspect ratio)
wmain <- 1500
hmain <- 1500  
umain <- 'px'
rmain <- 300 # dpi
cmain <- 'lzw' # lzw compression required by PLOS Biology
amain = "cleartype"
mmain <- c(4, 5, 1, 1) # margins around plot (b, l, t, r)
lmain <- 1 # axis labels always horizontal

cexlab <- 1.0
cexlegend <- 0.65

# 6.1a) Metabolic (shared slope): powr_a -------------------------------------

# Select model to plot
posterior <- posterior_all_powr_a

n = 25

## Base R plot

tiff("figures/powr_a_paper.tiff", width = wmain, height = hmain, units = umain, res = rmain, compression = cmain, antialias = amain)
# png("figures/powr_a_paper.png", width = wmain, height = hmain, units = umain, res = 300)
par(mfrow=c(1,1), las = lmain, mar = mmain)
palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  

plot(df_obs$move_log10bodymass_kg,  df_obs$move_log10avgspeed_ms,
     xlim=xlim_main,
     ylim=ylim_main,
     xlab = expression(body ~ mass ~ ~ ~ log[10](kg)), ## xlabel
     ylab = expression(travel ~ speed ~ ~ ~ log[10](m ~ s^-1)), ## ylabel
     col=df_obs$move_movement_mode,
     pch=fig_points,
     cex=0.4,
     cex.lab=cexlab,
     mgp=c(2.5,0.7,0) # adjusts position of (axis title, numbers, line)
)

legend("bottomright",
       bty = "n",
       legend = legend_names,
       pch = legend_points,
       cex=cexlegend
)

for (i in c(1,3,2)) {  # levels(df_obs$move_movement_mode): 1 "flying"  3 "swimming"  2 "running" (running gets drawn on top/last)  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  minmax_i <- df_obs %>% filter(Mode == i) %>% select(move_log10bodymass_kg) %>% range()
  
  x_pred = seq(from = minmax_i[1],
               to = minmax_i[2],
               length = n)
  
  x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))
  
  minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))
  
  x_pred_extr = seq(from = minmax_extr[1],
                    to = minmax_extr[2],
                    length = n)
  
  x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))
  
  # plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
  #      xlim=range(df_obs$move_log10bodymass_kg),
  #      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
  #      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
  #      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
  #      main=levels(df_obs$move_movement_mode)[i],
  #      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
  #      cex=1.25,
  #      cex.lab=1.25
  # )
  # 
  # Add legend / Reprint without Legend
  # legend("bottomleft",
  #        bty = "n",
  #        legend = c(levels(df_obs$animal_group)),
  #        pch = c(3,1,15,5,17,4,16,8,6,18),
  #        cex=1.25
  # )
  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  # Plot predictions over extrapolated data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr + log10(posterior[j, paste0("v_zero_Mode[",i,"]")])
  }
  
  y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
  lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)
  
  y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
  # 90% Prediction intervals for stochastic model
  y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(m in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                             mean = posterior[m, paste0("c")]*x_pred_extr + log10(posterior[m, paste0("v_zero_Mode[",i,"]")]),
                             sd = posterior[m, "sigma"])
  }
  
  # Plot predictions over observed data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred[j, ] = posterior[j, paste0("c")]*x_pred + log10(posterior[j, paste0("v_zero_Mode[",i,"]")])
  }
  
  y_cred_median = apply(y_cred, 2, function(x) median(x)) 
  lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)
  
  y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
}
dev.off()

# 6.2a) Allometric heat-dissipation (shared slope): satr_a -----------------------------------------------------------

# Select model to plot
posterior <- posterior_all_satr_a

n = 25

## Base R plot

## Base R plot
tiff("figures/satr_a_paper.tiff", width = wmain, height = hmain, units = umain, res = rmain, compression = cmain, antialias = amain)
# png("figures/satr_a_paper.png", width = wmain, height = hmain, units = umain, res = 300)
par(mfrow=c(1,1), las = lmain, mar = mmain)
palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  

plot(df_obs$move_log10bodymass_kg, df_obs$move_log10avgspeed_ms,
     xlim=xlim_main,
     ylim=ylim_main,
     xlab = expression(body ~ mass ~ ~ ~ log[10](kg)), ## xlabel
     ylab = expression(travel ~ speed ~ ~ ~ log[10](m ~ s^-1)), ## ylabel
     col=df_obs$move_movement_mode,
     pch=fig_points,
     cex=0.4,
     cex.lab=cexlab,
     mgp=c(2.5,0.7,0) # adjusts position of (axis title, numbers, line)
)

legend("bottomright",
       bty = "n",
       legend = legend_names,
       pch = legend_points,
       cex=cexlegend
)

for (i in c(1,3,2)) {  # levels(df_obs$move_movement_mode): 1 "flying"  3 "swimming"  2 "running" (running gets drawn on top/last)  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  minmax_i <- df_obs %>% filter(Mode == i) %>% select(move_log10bodymass_kg) %>% range()
  
  x_pred = seq(from = minmax_i[1],
               to = minmax_i[2],
               length = n)
  
  x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))
  
  minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))
  
  x_pred_extr = seq(from = minmax_extr[1],
                    to = minmax_extr[2],
                    length = n)
  
  x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))
  
  # plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
  #      xlim=range(df_obs$move_log10bodymass_kg),
  #      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
  #      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
  #      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
  #      main=levels(df_obs$move_movement_mode)[i],
  #      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
  #      cex=1.25,
  #      cex.lab=1.25
  # )
  # 
  # Add legend / Reprint without Legend
  # legend("bottomleft",
  #        bty = "n",
  #        legend = c(levels(df_obs$animal_group)),
  #        pch = c(3,1,15,5,17,4,16,8,6,18),
  #        cex=1.25
  # )
  
  # Plot predictions over extrapolated data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr - log10(posterior[j, paste0("k_zero")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c")]) + (1/(posterior[j, paste0("k_zero")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
  lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)
  
  y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
  # 90% Prediction intervals for stochastic model
  y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(m in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[m,paste0("a[",i,"]")]
    y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                             mean = posterior[m, paste0("c")]*x_pred_extr - log10(posterior[m, paste0("k_zero")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c")]) + (1/(posterior[m, paste0("k_zero")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                             sd = posterior[m, "sigma"])
  }
  
  # Plot predictions over observed data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred[j, ] = posterior[j, paste0("c")]*x_pred - log10(posterior[j, paste0("k_zero")]) - log10(x_raw_pred^(posterior[j, paste0("c")]) + (1/(posterior[j, paste0("k_zero")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median = apply(y_cred, 2, function(x) median(x)) 
  lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)
  
  y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
}
dev.off()

# 6.2c) Constant heat-dissipation (shared slope and variable maxima): satr_c -----------------------------------------------------------

# Select model to plot
posterior <- posterior_all_satr_c

n = 25

## Base R plot

## Base R plot
tiff("figures/satr_c_paper.tiff", width = wmain, height = hmain, units = umain, res = rmain, compression = cmain, antialias = amain)
# png("figures/satr_a_paper.png", width = wmain, height = hmain, units = umain, res = 300)
par(mfrow=c(1,1), las = lmain, mar = mmain)
palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  

plot(df_obs$move_log10bodymass_kg, df_obs$move_log10avgspeed_ms,
     xlim=xlim_main,
     ylim=ylim_main,
     xlab = expression(body ~ mass ~ ~ ~ log[10](kg)), ## xlabel
     ylab = expression(travel ~ speed ~ ~ ~ log[10](m ~ s^-1)), ## ylabel
     col=df_obs$move_movement_mode,
     pch=fig_points,
     cex=0.4,
     cex.lab=cexlab,
     mgp=c(2.5,0.7,0) # adjusts position of (axis title, numbers, line)
)

legend("bottomright",
       bty = "n",
       legend = legend_names,
       pch = legend_points,
       cex=cexlegend
)

# Loop through flying and running within air: 
# Medium: 1 = air; 
# Mode: 1 = flying, 2 = running
h = 1
for (i in c(1,2)) {  # levels(df_obs$move_movement_mode): 1 "flying"  3 "swimming"  2 "running" (running gets drawn on top/last)  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  minmax_i <- df_obs %>% filter(Mode == i & Medium == h) %>% select(move_log10bodymass_kg) %>% range()
  
  x_pred = seq(from = minmax_i[1],
               to = minmax_i[2],
               length = n)
  
  x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))
  
  minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))
  
  x_pred_extr = seq(from = minmax_extr[1],
                    to = minmax_extr[2],
                    length = n)
  
  x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))
  
  # plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
  #      xlim=range(df_obs$move_log10bodymass_kg),
  #      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
  #      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
  #      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
  #      main=levels(df_obs$move_movement_mode)[i],
  #      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
  #      cex=1.25,
  #      cex.lab=1.25
  # )
  # 
  # Add legend / Reprint without Legend
  # legend("bottomleft",
  #        bty = "n",
  #        legend = c(levels(df_obs$animal_group)),
  #        pch = c(3,1,15,5,17,4,16,8,6,18),
  #        cex=1.25
  # )
  
  # Plot predictions over extrapolated data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr - log10(posterior[j, paste0("k_zero_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c")]) + (1/(posterior[j, paste0("k_zero_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
  lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)
  
  y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
  # 90% Prediction intervals for stochastic model
  y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(m in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[m,paste0("a[",i,"]")]
    y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                             mean = posterior[m, paste0("c")]*x_pred_extr - log10(posterior[m, paste0("k_zero_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c")]) + (1/(posterior[m, paste0("k_zero_Medium[",h,"]")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                             sd = posterior[m, "sigma"])
  }
  
  # Plot predictions over observed data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred[j, ] = posterior[j, paste0("c")]*x_pred - log10(posterior[j, paste0("k_zero_Medium[",h,"]")]) - log10(x_raw_pred^(posterior[j, paste0("c")]) + (1/(posterior[j, paste0("k_zero_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median = apply(y_cred, 2, function(x) median(x)) 
  lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)
  
  y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
}

# Loop through swimming within water: 
# Medium: 2 = water; 
# Mode: 3 = swimming
# no loop needed
h = 2
i = 3 

minmax_i <- df_obs %>% filter(Mode == i & Medium == h) %>% select(move_log10bodymass_kg) %>% range()

x_pred = seq(from = minmax_i[1],
             to = minmax_i[2],
             length = n)

x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))

minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))

x_pred_extr = seq(from = minmax_extr[1],
                  to = minmax_extr[2],
                  length = n)

x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))

# plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
#      xlim=range(df_obs$move_log10bodymass_kg),
#      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
#      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
#      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
#      main=levels(df_obs$move_movement_mode)[i],
#      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
#      cex=1.25,
#      cex.lab=1.25
# )
# 
# Add legend / Reprint without Legend
# legend("bottomleft",
#        bty = "n",
#        legend = c(levels(df_obs$animal_group)),
#        pch = c(3,1,15,5,17,4,16,8,6,18),
#        cex=1.25
# )

# Plot predictions over extrapolated data range

# 90% Confidence (Credible) intervals for deterministic model
y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))

for(j in 1:nrow(posterior)) {
  # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
  y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr - log10(posterior[j, paste0("k_zero_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c")]) + (1/(posterior[j, paste0("k_zero_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
}

y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)

y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
# lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)

y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
# lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)

polygon(x = c(x_pred_extr, rev(x_pred_extr)),
        y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
        col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
        border = NA)

# 90% Prediction intervals for stochastic model
y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))

for(m in 1:nrow(posterior)) {
  # column i in posterior corresponds to a_i, alternatively reference by name: posterior[m,paste0("a[",i,"]")]
  y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                           mean = posterior[m, paste0("c")]*x_pred_extr - log10(posterior[m, paste0("k_zero_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c")]) + (1/(posterior[m, paste0("k_zero_Medium[",h,"]")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                           sd = posterior[m, "sigma"])
}

# Plot predictions over observed data range

# 90% Confidence (Credible) intervals for deterministic model
y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))

for(j in 1:nrow(posterior)) {
  # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
  y_cred[j, ] = posterior[j, paste0("c")]*x_pred - log10(posterior[j, paste0("k_zero_Medium[",h,"]")]) - log10(x_raw_pred^(posterior[j, paste0("c")]) + (1/(posterior[j, paste0("k_zero_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
}

y_cred_median = apply(y_cred, 2, function(x) median(x)) 
lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)

y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
# lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)

y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
# lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)

polygon(x = c(x_pred_extr, rev(x_pred_extr)),
        y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
        col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
        border = NA)

dev.off()

# 6.3a) Allometric heat-dissipation (shared slope): hump_a -------------------------------------------------

# Select model to plot
posterior <- posterior_all_hump_a

n = 25

## Base R plot
tiff("figures/hump_a_paper.tiff", width = wmain, height = hmain, units = umain, res = rmain, compression = cmain, antialias = amain)
# png("figures/hump_a_paper.png", width = wmain, height = hmain, units = umain, res = 300)
par(mfrow=c(1,1), las = lmain, mar = mmain)
palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  

plot(df_obs$move_log10bodymass_kg,  df_obs$move_log10avgspeed_ms,
     xlim=xlim_main,
     ylim=ylim_main,
     xlab = expression(body ~ mass ~ ~ ~ log[10](kg)), ## xlabel
     ylab = expression(travel ~ speed ~ ~ ~ log[10](m ~ s^-1)), ## ylabel
     col=df_obs$move_movement_mode,
     pch=fig_points,
     cex=0.4,
     cex.lab=cexlab,
     mgp=c(2.5,0.7,0) # adjusts position of (axis title, numbers, line)
)

legend("bottomright",
       bty = "n",
       legend = legend_names,
       pch = legend_points,
       cex=cexlegend
)

for (i in c(1,3,2)) {  # levels(df_obs$move_movement_mode): 1 "flying"  3 "swimming"  2 "running" (running gets drawn on top/last)  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  minmax_i <- df_obs %>% filter(Mode == i) %>% select(move_log10bodymass_kg) %>% range()
  
  x_pred = seq(from = minmax_i[1],
               to = minmax_i[2],
               length = n)
  
  x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))
  
  minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))
  
  x_pred_extr = seq(from = minmax_extr[1],
                    to = minmax_extr[2],
                    length = n)
  
  x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))
  
  # plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
  #      xlim=range(df_obs$move_log10bodymass_kg),
  #      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
  #      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
  #      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
  #      main=levels(df_obs$move_movement_mode)[i],
  #      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
  #      cex=1.25,
  #      cex.lab=1.25
  # )
  # 
  # Add legend / Reprint without Legend
  # legend("bottomleft",
  #        bty = "n",
  #        legend = c(levels(df_obs$animal_group)),
  #        pch = c(3,1,15,5,17,4,16,8,6,18),
  #        cex=1.25
  # )
  
  # Plot predictions over extrapolated data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr - log10(posterior[j, paste0("k_lambda")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
  lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)
  
  y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
  # 90% Prediction intervals for stochastic model
  y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(m in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                             mean = posterior[m, paste0("c")]*x_pred_extr - log10(posterior[m, paste0("k_lambda")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c")] + posterior[m, paste0("d")]) + (1/(posterior[m, paste0("k_lambda")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                             sd = posterior[m, "sigma"])
  }
  
  # Plot predictions over observed data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred[j, ] = posterior[j, paste0("c")]*x_pred - log10(posterior[j, paste0("k_lambda")]) - log10(x_raw_pred^(posterior[j, paste0("c")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median = apply(y_cred, 2, function(x) median(x)) 
  lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)
  
  y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
}
dev.off()

# 6.3b) Allometric cooling model hump_b -------------------------------------------------

# Select model to plot
posterior <- posterior_all_hump_b

n = 25

## Base R plot
tiff("figures/hump_b_paper.tiff", width = wmain, height = hmain, units = umain, res = rmain, compression = cmain, antialias = amain)
# png("figures/hump_b_paper.png", width = wmain, height = hmain, units = umain, res = 300)
par(mfrow=c(1,1), las = lmain, mar = mmain)
palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  

plot(df_obs$move_log10bodymass_kg,  df_obs$move_log10avgspeed_ms,
     xlim=xlim_main,
     ylim=ylim_main,
     xlab = expression(body ~ mass ~ ~ ~ log[10](kg)), ## xlabel
     ylab = expression(travel ~ speed ~ ~ ~ log[10](m ~ s^-1)), ## ylabel
     col=df_obs$move_movement_mode,
     pch=fig_points,
     cex=0.4,
     cex.lab=cexlab,
     mgp=c(2.5,0.7,0) # adjusts position of (axis title, numbers, line)
)

legend("bottomright",
       bty = "n",
       legend = legend_names,
       pch = legend_points,
       cex=cexlegend
)

for (i in c(1,3,2)) {  # levels(df_obs$move_movement_mode): 1 "flying"  3 "swimming"  2 "running" (running gets drawn on top/last)  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  minmax_i <- df_obs %>% filter(Mode == i) %>% select(move_log10bodymass_kg) %>% range()
  
  x_pred = seq(from = minmax_i[1],
               to = minmax_i[2],
               length = n)
  
  x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))
  
  minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))
  
  x_pred_extr = seq(from = minmax_extr[1],
                    to = minmax_extr[2],
                    length = n)
  
  x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))
  
  # plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
  #      xlim=range(df_obs$move_log10bodymass_kg),
  #      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
  #      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
  #      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
  #      main=levels(df_obs$move_movement_mode)[i],
  #      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
  #      cex=1.25,
  #      cex.lab=1.25
  # )
  # 
  # Add legend / Reprint without Legend
  # legend("bottomleft",
  #        bty = "n",
  #        legend = c(levels(df_obs$animal_group)),
  #        pch = c(3,1,15,5,17,4,16,8,6,18),
  #        cex=1.25
  # )
  
  # Plot predictions over extrapolated data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred_extr[j, ] = posterior[j, paste0("c_Mode[",i,"]")]*x_pred_extr - log10(posterior[j, paste0("k_lambda")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c_Mode[",i,"]")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
  lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)
  
  y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
  # 90% Prediction intervals for stochastic model
  y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(m in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                             mean = posterior[m, paste0("c_Mode[",i,"]")]*x_pred_extr - log10(posterior[m, paste0("k_lambda")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c_Mode[",i,"]")] + posterior[m, paste0("d")]) + (1/(posterior[m, paste0("k_lambda")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                             sd = posterior[m, "sigma"])
  }
  
  # Plot predictions over observed data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred[j, ] = posterior[j, paste0("c_Mode[",i,"]")]*x_pred - log10(posterior[j, paste0("k_lambda")]) - log10(x_raw_pred^(posterior[j, paste0("c_Mode[",i,"]")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median = apply(y_cred, 2, function(x) median(x)) 
  lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)
  
  y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
}
dev.off()

# 6.2c) Non-allometric cooling model hump_c -----------------------------------------------------------

# Select model to plot
posterior <- posterior_all_hump_c

n = 25

## Base R plot

## Base R plot
tiff("figures/hump_c_paper.tiff", width = wmain, height = hmain, units = umain, res = rmain, compression = cmain, antialias = amain)
# png("figures/satr_a_paper.png", width = wmain, height = hmain, units = umain, res = 300)
par(mfrow=c(1,1), las = lmain, mar = mmain)
palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  

plot(df_obs$move_log10bodymass_kg, df_obs$move_log10avgspeed_ms,
     xlim=xlim_main,
     ylim=ylim_main,
     xlab = expression(body ~ mass ~ ~ ~ log[10](kg)), ## xlabel
     ylab = expression(travel ~ speed ~ ~ ~ log[10](m ~ s^-1)), ## ylabel
     col=df_obs$move_movement_mode,
     pch=fig_points,
     cex=0.4,
     cex.lab=cexlab,
     mgp=c(2.5,0.7,0) # adjusts position of (axis title, numbers, line)
)

legend("bottomright",
       bty = "n",
       legend = legend_names,
       pch = legend_points,
       cex=cexlegend
)

# Loop through flying and running within air: 
# Medium: 1 = air; 
# Mode: 1 = flying, 2 = running
h = 1
for (i in c(1,2)) {  # levels(df_obs$move_movement_mode): 1 "flying"  3 "swimming"  2 "running" (running gets drawn on top/last)  
  # Set colour pallete inside for loop
  move_mode_colours <- palette(c("olivedrab2","salmon1","skyblue2")) # levels(df_obs$move_movement_mode): "flying"   "running"  "swimming"  
  
  minmax_i <- df_obs %>% filter(Mode == i & Medium == h) %>% select(move_log10bodymass_kg) %>% range()
  
  x_pred = seq(from = minmax_i[1],
               to = minmax_i[2],
               length = n)
  
  x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))
  
  minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))
  
  x_pred_extr = seq(from = minmax_extr[1],
                    to = minmax_extr[2],
                    length = n)
  
  x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))
  
  # plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
  #      xlim=range(df_obs$move_log10bodymass_kg),
  #      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
  #      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
  #      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
  #      main=levels(df_obs$move_movement_mode)[i],
  #      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
  #      cex=1.25,
  #      cex.lab=1.25
  # )
  # 
  # Add legend / Reprint without Legend
  # legend("bottomleft",
  #        bty = "n",
  #        legend = c(levels(df_obs$animal_group)),
  #        pch = c(3,1,15,5,17,4,16,8,6,18),
  #        cex=1.25
  # )
  
  # Plot predictions over extrapolated data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr - log10(posterior[j, paste0("k_lambda_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
  lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)
  
  y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
  # 90% Prediction intervals for stochastic model
  y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))
  
  for(m in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[m,paste0("a[",i,"]")]
    y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                             mean = posterior[m, paste0("c")]*x_pred_extr - log10(posterior[m, paste0("k_lambda_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c")] + posterior[m, paste0("d")]) + (1/(posterior[m, paste0("k_lambda_Medium[",h,"]")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                             sd = posterior[m, "sigma"])
  }
  
  # Plot predictions over observed data range
  
  # 90% Confidence (Credible) intervals for deterministic model
  y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))
  
  for(j in 1:nrow(posterior)) {
    # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
    y_cred[j, ] = posterior[j, paste0("c")]*x_pred - log10(posterior[j, paste0("k_lambda_Medium[",h,"]")]) - log10(x_raw_pred^(posterior[j, paste0("c")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
  }
  
  y_cred_median = apply(y_cred, 2, function(x) median(x)) 
  lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)
  
  y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
  # lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
  # lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)
  
  polygon(x = c(x_pred_extr, rev(x_pred_extr)),
          y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
          col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
          border = NA)
  
}

# Loop through swimming within water: 
# Medium: 2 = water; 
# Mode: 3 = swimming
# no loop needed
h = 2
i = 3 

minmax_i <- df_obs %>% filter(Mode == i & Medium == h) %>% select(move_log10bodymass_kg) %>% range()

x_pred = seq(from = minmax_i[1],
             to = minmax_i[2],
             length = n)

x_raw_pred = 10^(seq(from=minmax_i[1], to=minmax_i[2], length = n))

minmax_extr <- c(min(df_obs$move_log10bodymass_kg-1),max(df_obs$move_log10bodymass_kg+2))

x_pred_extr = seq(from = minmax_extr[1],
                  to = minmax_extr[2],
                  length = n)

x_raw_pred_extr = 10^(seq(from=minmax_extr[1], to=minmax_extr[2], length = n))

# plot(dat_sub$move_log10bodymass_kg,  dat_sub$move_log10avgspeed_ms,
#      xlim=range(df_obs$move_log10bodymass_kg),
#      ylim=c(min(df_obs$move_log10avgspeed_ms)-1,max(df_obs$move_log10avgspeed_ms)+1),
#      xlab = expression(paste("lo", g[10]," body size [kg]")), ## xlabel
#      ylab = expression(paste("lo", g[10]," travel speed [m/s]")), ## ylabel
#      main=levels(df_obs$move_movement_mode)[i],
#      pch=c(3,1,15,5,17,4,16,8,6,18)[as.numeric(dat_sub$animal_group)],
#      cex=1.25,
#      cex.lab=1.25
# )
# 
# Add legend / Reprint without Legend
# legend("bottomleft",
#        bty = "n",
#        legend = c(levels(df_obs$animal_group)),
#        pch = c(3,1,15,5,17,4,16,8,6,18),
#        cex=1.25
# )

# Plot predictions over extrapolated data range

# 90% Confidence (Credible) intervals for deterministic model
y_cred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))

for(j in 1:nrow(posterior)) {
  # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
  y_cred_extr[j, ] = posterior[j, paste0("c")]*x_pred_extr - log10(posterior[j, paste0("k_lambda_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[j, paste0("c")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
}

y_cred_median_extr = apply(y_cred_extr, 2, function(x) median(x)) 
lines(x_pred_extr, y_cred_median_extr, col=move_mode_colours[i], lwd=2.0, lty=2)

y_cred_q05_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.05)) 
# lines(x_pred_extr, y_cred_q05_extr, col=move_mode_colours[i], lwd=1.5, lty=2)

y_cred_q95_extr = apply(y_cred_extr, 2, function(x) quantile(x, probs=0.95)) 
# lines(x_pred_extr, y_cred_q95_extr, col=move_mode_colours[i], lwd=1.5, lty=2)

polygon(x = c(x_pred_extr, rev(x_pred_extr)),
        y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
        col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
        border = NA)

# 90% Prediction intervals for stochastic model
y_pred_extr = matrix(0, nrow=nrow(posterior), ncol=length(x_pred_extr))

for(m in 1:nrow(posterior)) {
  # column i in posterior corresponds to a_i, alternatively reference by name: posterior[m,paste0("a[",i,"]")]
  y_pred_extr[m, ] = rnorm(n = length(x_pred_extr), 
                           mean = posterior[m, paste0("c")]*x_pred_extr - log10(posterior[m, paste0("k_lambda_Medium[",h,"]")]) - log10(x_raw_pred_extr^(posterior[m, paste0("c")] + posterior[m, paste0("d")]) + (1/(posterior[m, paste0("k_lambda_Medium[",h,"]")]*posterior[m, paste0("v_zero_Mode[",i,"]")]))),
                           sd = posterior[m, "sigma"])
}

# Plot predictions over observed data range

# 90% Confidence (Credible) intervals for deterministic model
y_cred = matrix(0, nrow=nrow(posterior), ncol=length(x_pred))

for(j in 1:nrow(posterior)) {
  # column i in posterior corresponds to a_i, alternatively reference by name: posterior[j,paste0("a[",i,"]")]
  y_cred[j, ] = posterior[j, paste0("c")]*x_pred - log10(posterior[j, paste0("k_lambda_Medium[",h,"]")]) - log10(x_raw_pred^(posterior[j, paste0("c")] + posterior[j, paste0("d")]) + (1/(posterior[j, paste0("k_lambda_Medium[",h,"]")]*posterior[j, paste0("v_zero_Mode[",i,"]")])))
}

y_cred_median = apply(y_cred, 2, function(x) median(x)) 
lines(x_pred, y_cred_median, col=move_mode_colours[i], lwd=2.0)

y_cred_q05 = apply(y_cred, 2, function(x) quantile(x, probs=0.05)) 
# lines(x_pred, y_cred_q05, col=move_mode_colours[i], lwd=1.5, lty=2)

y_cred_q95 = apply(y_cred, 2, function(x) quantile(x, probs=0.95)) 
# lines(x_pred, y_cred_q95, col=move_mode_colours[i], lwd=1.5, lty=2)

polygon(x = c(x_pred_extr, rev(x_pred_extr)),
        y = c(y_cred_q05_extr, rev(y_cred_q95_extr)),
        col=adjustcolor(move_mode_colours[i], alpha.f = 0.10),
        border = NA)

dev.off()

################
################ End
#############
